//= jquery.js
//= uikit.js
//= swiper.js
//= components/test.js
document.addEventListener("DOMContentLoaded", function () {
  //= components/swiper-slider.js
});